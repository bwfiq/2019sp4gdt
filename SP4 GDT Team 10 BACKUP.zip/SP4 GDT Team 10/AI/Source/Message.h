#ifndef MESSAGE_H
#define MESSAGE_H

#include <string>

class Message
{
public:
	Message() {}
	virtual ~Message() {}
};

#endif